#!/bin/bash
echo 03-10 >> Dealer_working_during_losses
awk '{print $1, $2, $5, $6}' 0310_Dealer_schedule | grep "05:00:00 AM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0310_Dealer_schedule | grep "08:00:00 AM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0310_Dealer_schedule | grep "02:00:00 PM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0310_Dealer_schedule | grep "08:00:00 PM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0310_Dealer_schedule | grep "11:00:00 PM" >> Dealer_working_during_losses 

echo 03-12 >> Dealer_working_during_losses
awk '{print $1, $2, $5, $6}' 0312_Dealer_schedule | grep "05:00:00 AM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0312_Dealer_schedule | grep "08:00:00 AM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0312_Dealer_schedule | grep "02:00:00 PM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0312_Dealer_schedule | grep "08:00:00 PM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0312_Dealer_schedule | grep "11:00:00 PM" >> Dealer_working_during_losses 

echo 03-15 >> Dealer_working_during_losses
awk '{print $1, $2, $5, $6}' 0315_Dealer_schedule | grep "05:00:00 AM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0315_Dealer_schedule | grep "08:00:00 AM" >> Dealer_working_during_losses 
awk '{print $1, $2, $5, $6}' 0315_Dealer_schedule | grep "02:00:00 PM" >> Dealer_working_during_losses 

echo "Billy Jones" | cat >> Notes_Dealer_Analysis
grep -c "Billy Jones" Dealer_working_during_losses | cat >> Notes_Dealer_Analysis
